
import { NgModule } from'@angular/core';
import { CommonModule } from'@angular/common';
import { CreateAccountComponent } from'./create-account/create-account.component';
import { ShowBalanceComponent } from'./show-balance/show-balance.component';
import { DepositeComponent } from'./deposite/deposite.component';
import { WithdrawComponent } from'./withdraw/withdraw.component';
import { FundTransferComponent } from'./fund-transfer/fund-transfer.component';
import { PrintTransactionComponent } from'./print-transaction/print-transaction.component';
import { RouterModule,Routes} from'@angular/router';
const routes:Routes= [
 {
path:'Create',
component:CreateAccountComponent
// redirectTo:'List-Student',
// pathMatch: 'full'
 },
 {
path:'Balance',
component:ShowBalanceComponent
 },
 {
path:'Deposit',
component:DepositeComponent
 },
 {
path:'Withdraw',
component:WithdrawComponent
 },
 {
path:'Transfer',
component:FundTransferComponent
 },
 {
path:'Print',
component:PrintTransactionComponent
 }
];
@NgModule({
imports: [RouterModule.forRoot(routes)],
exports: [RouterModule],
declarations: []
})
export class AppRoutingModule { }

