package com.cap.service;

import java.util.List;
import com.cap.bean.BankDetails;
import com.cap.bean.BankTransactions;

 

public interface BankService 
{
    long createAccount(BankDetails bankdetails);
    BankDetails showDetails(long accNum);
    long depositDetails(long accNum,long depAcc);
    long withdrawDetails(long accNum,long withDraw);
    long fundTransfer(long accNum4,long accNum5,long fundTrans);
    List<BankTransactions> printTransactions();
    boolean validateName(String custName);
    boolean validateMobNum(long custMobNum);
    boolean validateAccType(String accType);
}