package com.cap.ui;

import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;


import com.cap.bean.BankDetails;
import com.cap.bean.BankTransactions;
import com.cap.exception.AccountNumberNotFoundException;
import com.cap.service.BankService;
import com.cap.service.BankServiceImp1;


public class BankMainui {
    static BankService service1 = new BankServiceImp1();
    static Scanner scanner = new Scanner(System.in);


    public static void main(String[] args) {
        while (true) {
            String option=null;
            System.out.println("Welcome to Bank payment Wallet");
            System.out.println("******************************");
            System.out.println("Select any one option from the required option:");
            System.out.println("-----------------------------------------------");
            System.out.println(
                    "1.Create Account\n2.Deposit\n3.Withdraw\n4.Fund Transfer\n5.Show Balance\n6.Print Transaction");
            //option = scanner.nextInt();
            try
            {
                 option = scanner.next();
            }
            catch(Exception ae)
            {
                System.err.println("Please Enter from the above numbers Only ");
            }
            /*finally
            {
                System.err.println("Please Enter from the above numbers Only");
            }*/
            /*System.err.println("Please Enter from the above numbers Only");*/
    
            
            switch (option) {
            case "1":// Create Account
                String custName;
                String accType=null ;
                long custMobNum;
                boolean isName = false;
                boolean isNum = false;
                boolean isAccType = false;
                // validation for name
                do {
                    System.out.println("Enter your name: ");
                    custName = scanner.next();
                    isName = service1.validateName(custName);


                    if (!isName) {
                        System.out.println("Please enter first letter of name in Capital Alphabet: ");
                    }
                } while (!isName);


                // validation for mobile number
                do {
                    System.out.println("Enter you mobile number: ");
                    custMobNum = scanner.nextLong();
                    isNum = service1.validateMobNum(custMobNum);


                    if (!isNum) {
                        System.out.println(
                                "Please Enter vaild phone number starting from 6 or 7 or 8 or 9 and having 10 digits.");
                    }
                } while (!isNum);
                // validation for Account Type
                do {
                    System.out.println("Enter the type of your account: ");
                    String accType1 = scanner.next();
                    isAccType = service1.validateAccType(accType1);


                    if (isAccType) {
                        System.out.println("Please Enter savings or current.");
                    }
                } while (isAccType);


                System.out.println("Enter the first minimum balance: ");
                long accBal = scanner.nextLong();
                System.out.println("Enter the branch: ");
                String custBranch = scanner.next();
                BankDetails bankdetails = new BankDetails();
                bankdetails.setCustName(custName);
                bankdetails.setCustMobNum(custMobNum);
                bankdetails.setAccType(accType);
                bankdetails.setAccBal(accBal);
                bankdetails.setCustBranch(custBranch);
                service1.createAccount(bankdetails);
                System.out.println("Your Account Number is: " + bankdetails.getAccNum());
                System.out.println("-----Account Created Successfully------");
                System.out.println("Thank you for your service");
                System.out.println("\n\n");
                break; 
case "2":// Deposit Amount
                System.out.println("******Deposit******");
                System.out.println("-------------------");
                try {
                    System.out.println("Enter your Account number: ");
                    long accNum2 = scanner.nextLong();
                    System.out.println("Enter the amount for Deposit: ");
                    long depAcc = scanner.nextLong();
                    long depdet = service1.depositDetails(accNum2, depAcc);
                    System.out.println("Your Balance after depositing is: " + depdet);
                    System.out.println("Thank you for your service");
                    System.out.println("\n\n");
                } catch (AccountNumberNotFoundException e) {
                    System.out.println(e.getMessage());
                } catch (InputMismatchException e) {
                    System.out.println("Enter Account Number, Please dont enter String");
                }


                break;
            case "3":// Withdraw Amount
                System.out.println("******Withdraw******");
                System.out.println("---------------------");
                try {
                    System.out.println("Enter your Account number: ");
                    long accNum3 = scanner.nextLong();
                    System.out.println("Enter the amount for Withdrawing: ");
                    long withDraw = scanner.nextLong();
                    long witdraw = service1.withdrawDetails(accNum3, withDraw);
                    System.out.println("Your Balance after withdrawing is: " + witdraw);
                    System.out.println("Thank you for your service");
                    System.out.println("\n\n");
                } catch (AccountNumberNotFoundException e) {
                    System.out.println(e.getMessage());
                } catch (InputMismatchException e) {
                    System.out.println("Enter Account Number, Please dont enter String");
                }
                break;


            case "4":// Fund Transfer
                System.out.println("******Fund Transfer******");
                System.out.println("--------------------------");
                try {
                    System.out.println("Enter your Account Number: ");
                    long accNum4 = scanner.nextLong();
                    System.out.println("Enter the Account Number of the person whom you want to tranfer money to: ");
                    long accNum5 = scanner.nextLong();
                    System.out.println("Enter the Amount, How much you want to transfer: ");
                    long fundTrans = scanner.nextLong();
                    long funTrans = service1.fundTransfer(accNum4, accNum5, fundTrans);
                    System.out.println("Your Balance after transferring amount is: " + funTrans);
                    System.out.println("Thank you for service");
                    System.out.println("\n\n");
                } catch (AccountNumberNotFoundException e) {
                    System.out.println(e.getMessage());
                } catch (InputMismatchException e) {
                    System.out.println("Enter Account Number, Please dont enter String");
                }
                break;
            case "5":// Show All the Details
                System.out.println("******Show Details******");
                System.out.println("------------------------");
                try {
                    System.out.println("Please enter your Account number to provide you with your details: ");
                    long accNum1 = scanner.nextLong();
                    BankDetails bandet = service1.showDetails(accNum1);
                    System.out.println(bandet);
                    System.out.println("\n\n");
                } catch (AccountNumberNotFoundException e) {
                    System.out.println(e.getMessage());
                } catch (InputMismatchException e) {
                    System.out.println("Enter Account Number, Please dont enter String");
                }
                break;


            case "6":// Print All the Transactions
                System.out.println("******Print Transactions******");
                /*
                 * System.out.println("Enter the account number: "); long
                 * accNum6=scanner.nextLong();
                 */
                List<BankTransactions> result = service1.printTransactions();
                Iterator<BankTransactions> itr = result.iterator();
                while (itr.hasNext()) {
                    BankTransactions tran = itr.next();
                    // System.out.println(tran);
                    System.out.print("Account Number: " + tran.getAccNum() + "\t" + "\t");
                    System.out.print("Customer Branch: " + tran.getCustBranch() + "\t" + "\t");
                    System.out.print("Account Number: " + tran.getCustMobNum() + "\t" + "\t");
                    System.out.print("Customer Name: " + tran.getCustName() + "\t" + "\t");
                    System.out.print("From Account Number: " + tran.getFromAcc() + "\t" + "\t");
                    System.out.print("To Account Number: " + tran.getToAcc() + "\t" + "\t");
                    System.out.print("Transaction ID: " + tran.getTransId() + "\t" + "\t");
                    System.out.print("Transaction Type: " + tran.getTransType() + "\t" + "\t");
                    System.out.print("Transaction Old Balance: " + tran.getTransOldBal() + "\t" + "\t");
                    System.out.println("Transaction New Balance: " + tran.getTransNewBal() + "\t" + "\t");
                }


            case "7":
                System.out.println("Thank you for choosing our bank ");
                //break;
                System.exit(0);
            }
        }
    }
}
 






