package com.cap.dao;

import org.junit.Assert;
import org.junit.Test;

import com.cap.bean.BankDetails;

public class BankDaoImp1Test {
	// positive response
	BankDaoImp1 dao = new BankDaoImp1();

	@Test
	public void createAcc_1() {
		BankDetails bank = new BankDetails();
		bank.setAccBal(1234);
		bank.setAccNum(1000);
		bank.setAccType("savings");
		bank.setCustMobNum(989899898);
		bank.setCustName("qwerty");
		long AccNum=bank.getAccNum();
        long expectedAccNum=1000;
		Assert.assertEquals(expectedAccNum, AccNum);


	}

	// negative response
	/*@Test
	public void createAcc_2() {
		BankDetails bank = new BankDetails();
		bank.setAccBal(1234);
		bank.setAccNum(1000);
		bank.setAccType("savings");
		bank.setCustMobNum(989899898);
		bank.setCustName("qwerty");
		long AccNum=bank.getAccNum();
        long expectedAccNum=3000;
		Assert.assertEquals(expectedAccNum, AccNum);

	}*/
}