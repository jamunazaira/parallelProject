package com.cap.service;

import java.util.List;

 

import com.cap.bean.BankDetails;
import com.cap.bean.BankTransactions;
import com.cap.dao.BankDaoImp1;

 

public class BankServiceImp1 implements BankService {
    BankDetails bean = new BankDetails();
    BankDaoImp1 dao = new BankDaoImp1();
    
    @Override
    public long createAccount(BankDetails bankdetails) {

        return dao.createAccount(bankdetails);
    }

 

    @Override
    public long showDetails(long accNum) {
        long bade = dao.showDetails(accNum);
        return bade;
    }

 

    @Override
    public long depositDetails(long accNum, long depAcc) {
        long depDet = dao.depositDetails(accNum, depAcc);
        return depDet;
    }

 

    @Override
    public long withdrawDetails(long accNum, long withDraw) {
        long withDraw1 = dao.withdrawDetails(accNum, withDraw);
        return withDraw1;
    }

 

    @Override
    public long fundTransfer(long accNum4, long accNum5, long fundTrans) {
        long fundTrans1 = dao.fundTransfer(accNum4, accNum5, fundTrans);
        return fundTrans1;
    }

 

    @Override
    public void printTransactions() 
    {
        dao.printTransactions();
    }

 

    //Validation for name
    @Override
    public boolean validateName(String custName)
    {
        if(custName.matches("[A-Z][a-zA-Z]*"))
        {
            return true;
        }
        else
        {
            return false;
        }
    
    }

 

    //Validation for Mobile number
    @Override
    public boolean validateMobNum(long custMobNum) 
    {
        String mobN=Long.toString(custMobNum);
        if(mobN.matches("[6-9][0-9]{9}"))
        {
            return true;
        }
        else
        {
            return false;
        }
            
    }

 

    //Validation to check the type of account
    @Override
    public boolean validateAccType(String accType) 
    {
        
        if(accType.equalsIgnoreCase("savings") || accType.equalsIgnoreCase("current"))
        {
            return false;
        }
        else
        {
            return true;
        }
        
    }
}