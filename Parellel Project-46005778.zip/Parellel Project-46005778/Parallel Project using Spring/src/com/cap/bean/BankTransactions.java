package com.cap.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="BankTran11")

public class BankTransactions {
	 @Id
	    @GeneratedValue
	    @Column(name="transId",length=10)
    private long transId;
	 @Column(name="transOldBal",length=10)
    private long transOldBal;
	 @Column(name="transNewBal",length=10)
    private long transNewBal;
	 @Column(name="fromAcc",length=10)
    private long fromAcc;
	 @Column(name="toAcc",length=10)
    private long toAcc;
	public long getTransId() {
		return transId;
	}
	public void setTransId(long transId) {
		this.transId = transId;
	}
	
	public long getTransOldBal() {
		return transOldBal;
	}
	public void setTransOldBal(long transOldBal) {
		this.transOldBal = transOldBal;
	}
	public long getTransNewBal() {
		return transNewBal;
	}
	public void setTransNewBal(long transNewBal) {
		this.transNewBal = transNewBal;
	}
	public long getFromAcc() {
		return fromAcc;
	}
	public void setFromAcc(long fromAcc) {
		this.fromAcc = fromAcc;
	}
	public long getToAcc() {
		return toAcc;
	}
	public void setToAcc(long toAcc) {
		this.toAcc = toAcc;
	}
	@Override
	public String toString() {
		return "BankTransactions [transId=" + transId +  ", transOldBal=" + transOldBal
				+ ", transNewBal=" + transNewBal + ", fromAcc=" + fromAcc + ", toAcc=" + toAcc + "]";
	}
    
//setter and getters
    
  

 

  

 


    

}