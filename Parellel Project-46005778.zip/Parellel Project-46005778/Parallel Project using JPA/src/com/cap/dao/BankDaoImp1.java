package com.cap.dao;

//import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.cap.bean.BankDetails;
import com.cap.bean.BankTransactions;

 

public class BankDaoImp1 implements BankDao {
	 //Connection conn=DBConnect.getConnection();
	
	private EntityManager entityManager;

	public BankDaoImp1() {
		entityManager = JPAUtil.getEntityManager();
	}
	
	
	@Override
	public long createAccount(BankDetails bankdetails) {
        entityManager.persist(bankdetails);
        return bankdetails.getAccNum();
    }

	@Override
	public long showDetails(long accNum) {
		 BankDetails bal=entityManager.find(BankDetails.class, accNum);
	        return bal.getAccBal();
		
	}

	@Override
	public long depositDetails(long accNum, long depAcc) {
		 BankDetails bank1=entityManager.find(BankDetails.class, accNum);
		    long newbal=bank1.getAccBal();
		    long newbal1=depAcc+newbal;
		    bank1.setAccBal(newbal1);
		    entityManager.merge(bank1);
		    BankTransactions t=new BankTransactions();
		       t.setFromAcc(accNum);
		       
		       t.setTransOldBal(newbal);
		      
		       t.setTransNewBal(newbal1);
		      
		     
		       entityManager.persist(t);
		        return newbal1;
	}

	@Override
	public long withdrawDetails(long accNum, long withDraw) {
		BankDetails bank2=entityManager.find(BankDetails.class, accNum);
        long newbal2=bank2.getAccBal();
        long newbal3=newbal2-withDraw;
        bank2.setAccBal(newbal3);
        entityManager.merge(bank2);
        BankTransactions t=new BankTransactions();
        t.setFromAcc(accNum);
        t.setTransOldBal(newbal2);
       
        t.setTransNewBal(newbal3);
       
        entityManager.persist(t);
            return newbal3;
	}

	@Override
	public long fundTransfer(long accNum4, long accNum5, long fundTrans) {
		   BankDetails bank3=entityManager.find(BankDetails.class,accNum4);
	        long newbal2=bank3.getAccBal();
	        long newbal3=newbal2-fundTrans;
	        bank3.setAccBal(newbal3);
	        entityManager.merge(bank3);
	        BankTransactions  t=new BankTransactions();
            t.setFromAcc(accNum4);
            t.setToAcc(accNum5);
            t.setTransOldBal(newbal2);
              
               t.setTransNewBal(newbal3);
            entityManager.persist(t);
	       
	        BankDetails bank4=entityManager.find(BankDetails.class,accNum5);
	        long newbal=bank4.getAccBal();
	        long newbal1=newbal+fundTrans;
	        bank4.setAccBal(newbal1);
	        entityManager.merge(bank4);
	        BankTransactions t1=new BankTransactions();
            t1.setFromAcc(accNum4);

 

          t1.setToAcc(accNum5);
           t1.setTransOldBal(newbal);
          
           t1.setTransNewBal(newbal1);
         
           entityManager.persist(t);
	            return newbal3;
	}

	@Override
	public void printTransactions() {
		 TypedQuery<BankTransactions> q2=entityManager.createQuery("select c from BankTransactions c",BankTransactions.class);
         List<BankTransactions> l1=q2.getResultList();
         for(BankTransactions em1:l1)
         {
             System.out.println(em1.getTransId()+"  "+em1.getFromAcc()+"  "+em1.getToAcc()+"  "+em1.getTransOldBal()+"  "+em1.getTransNewBal());
         }
		
	}

	@Override
	public void commitTransaction() {
    
		entityManager.getTransaction().commit();
		
	}

	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
		
	}

}