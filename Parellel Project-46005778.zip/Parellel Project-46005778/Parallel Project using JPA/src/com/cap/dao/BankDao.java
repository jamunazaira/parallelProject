package com.cap.dao;

import java.util.List;

 

import com.cap.bean.BankDetails;
import com.cap.bean.BankTransactions;

 


public interface BankDao 
{
    long createAccount(BankDetails bankdetails);
    long showDetails(long accNum);
    long depositDetails(long accNum,long depAcc);
    long withdrawDetails(long accNum,long withDraw);
    long fundTransfer(long accNum4,long accNum5,long fundTrans);
    void printTransactions();
    public abstract void commitTransaction();

    public abstract void beginTransaction(); 
    
}